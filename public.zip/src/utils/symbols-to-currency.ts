export const SYMBOL_TO_CURRENCY: Record<string, string> = {
  $: 'USD', // Default to USD for $
  '€': 'EUR', // Euro
  '£': 'GBP', // British Pound
  '¥': 'JPY', // Japanese Yen
  '₹': 'INR', // Indian Rupee
  '₩': 'KRW', // South Korean Won
  '₽': 'RUB', // Russian Ruble
  '₫': 'VND', // Vietnamese Dong
  '₪': 'ILS', // Israeli Shekel
  '₱': 'PHP', // Philippine Peso
  '₣': 'CHF', // Swiss Franc
  '฿': 'THB', // Thai Baht
  '₴': 'UAH', // Ukrainian Hryvnia
  '₡': 'CRC', // Costa Rican Colón
  '₤': 'TRL', // Turkish Lira (historical, replaced by "TRY")
  '₭': 'LAK', // Lao Kip
  '₮': 'MNT', // Mongolian Tögrög
  '₦': 'NGN', // Nigerian Naira
  '₲': 'PYG', // Paraguayan Guarani
  '₵': 'GHS', // Ghanaian Cedi
  '₸': 'KZT', // Kazakhstani Tenge
  '₢': 'BRL', // Brazilian Cruzeiro (historical, replaced by "BRL")
  '₥': 'MMK', // Myanmar Kyat
  '₧': 'ESP', // Spanish Peseta (historical, replaced by EUR)
  '₨': 'INR', // Indian Rupee, but also used in other countries
  '৳': 'BDT', // Bangladeshi Taka
  '៛': 'KHR', // Cambodian Riel
  '₺': 'TRY', // Turkish Lira
  '₼': 'AZN', // Azerbaijani Manat
  '৲': 'INR', // Bengali Rupee Mark (historical)
  '﷼': 'IRR', // Iranian Rial
  'ر.س': 'SAR', // Saudi Riyal
  'د.إ': 'AED', // UAE Dirham
  '₿': 'BTC', // Bitcoin (cryptocurrency)
}
