'use client'

import { Category } from '@/core/domain/category'
import { BiddoSettings } from '@/core/domain/settings'
import React, { createContext, useState } from 'react'

export interface AppContextType {
  navPathName: string
  setNavPathName: (name: string) => void
  currentLanguage: string
  setCurrentLanguage: React.Dispatch<React.SetStateAction<string>>
  scrollDirection: string
  setScrollDirection: React.Dispatch<React.SetStateAction<string>> | undefined
  appSettings: BiddoSettings
  appCategories: Category[]
}

export const AppContext = createContext<AppContextType | undefined>(undefined)

const AppProvider = ({
  children,
  lang,
  settings,
  categories,
}: {
  children: React.ReactNode
  lang: string
  settings: Record<string, unknown>
  categories: Record<string, unknown>[]
}) => {
  const [currentLanguage, setCurrentLanguage] = useState<string>(lang)
  const [navPathName, setNavMapName] = useState<string>('/')
  const [scrollDirection, setScrollDirection] = useState<string>('')

  const appSettings = BiddoSettings.fromJSON(settings)
  const appCategories = categories.map((category) => Category.fromJSON(category))

  const contextValue: AppContextType = {
    navPathName,
    setNavPathName: setNavMapName,
    currentLanguage,
    setCurrentLanguage,
    scrollDirection,
    setScrollDirection,
    appSettings,
    appCategories,
  }

  return <AppContext.Provider value={contextValue}>{children}</AppContext.Provider>
}

export default AppProvider
