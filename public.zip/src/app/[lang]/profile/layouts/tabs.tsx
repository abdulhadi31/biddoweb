import { AccountInfo } from '@/components/account/info'
import { ShareButton } from '@/components/share/button'
import { t } from 'i18next'
import Link from 'next/link'
import { ProfileDetailsTabs } from '../components/tabs'
import { ProfileTabsContent } from '../components/tabs-content'
import { Account } from '@/core/domain/account'
import { Auction } from '@/core/domain/auction'
import { Review } from '@/core/domain/review'
import { ProfileTabsEnum } from '../root'

export const ProfileTabsLayout = (props: {
  profile: Account
  activeNav: ProfileTabsEnum
  initialAuctions: Auction[]
  initialBids: Auction[]
  initialReviews: Review[]
  isMobile: boolean
  handleChangeTab: (tab: ProfileTabsEnum) => void
  handleFollowDone: (accountId: string) => void
  handleUnfollowDone: (accountId: string) => void
}) => {
  const {
    profile,
    activeNav,
    initialAuctions,
    initialBids,
    initialReviews,
    handleChangeTab,
    handleFollowDone,
    handleUnfollowDone,
  } = props

  return (
    <div className="row mr-0 ml-0 mt-30 mt-sm-5 mb-100 w-100">
      <div className="account-details-header">
        <div className="account-details-header-top">
          <AccountInfo account={profile} />
          <div className="d-flex align-items-center gap-4 see-how-others-see-you">
            <Link href={`/account/${profile.id}`}>
              <span className="blue-text">{t('info.see_how_others_see_you')}</span>
            </Link>
            <ShareButton
              fullWidth
              url={`/account/${profile.id}`}
              title={t('share.check_account')}
            />
          </div>
        </div>

        <div className="mt-30">
          <ProfileDetailsTabs
            profile={profile}
            activeNav={activeNav}
            handleChangeTab={handleChangeTab}
          />
        </div>
      </div>

      <div className="mb-30 mt-40 p-0">
        <ProfileTabsContent
          profile={profile}
          sidebarTabs={false}
          activeNav={activeNav}
          initialAuctions={initialAuctions}
          initialBids={initialBids}
          initialReviews={initialReviews}
          isMobile={props.isMobile}
          handleFollowDone={handleFollowDone}
          handleUnfollowDone={handleUnfollowDone}
        />
      </div>
    </div>
  )
}
