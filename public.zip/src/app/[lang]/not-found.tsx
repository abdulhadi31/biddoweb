import { NotFoundPage } from '@/components/common/404'

export default async function NotFound() {
  return (
    <main>
      <NotFoundPage />
    </main>
  )
}
