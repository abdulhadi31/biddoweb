'use client'
import { useTranslation } from '@/app/i18n/client'
import LoveButton from '@/components/common/love-button'
import useGlobalContext from '@/hooks/use-context'
import { observer } from 'mobx-react-lite'
import ShowMoreText from 'react-show-more-text'
import { Auction } from '@/core/domain/auction'
import { AppStore } from '@/core/store'
import { useEffect, useState } from 'react'
import dayjs from 'dayjs'
import { ShareButton } from '@/components/share/button'

export const AuctionDetailsContentSection = observer(
  (props: {
    auction: Auction
    openReport: () => void
    handleLoveTap: (isLiked: boolean) => boolean
  }) => {
    const { auction, openReport } = props
    const globalContext = useGlobalContext()
    const currentLanguage = globalContext.currentLanguage
    const { t } = useTranslation(currentLanguage)

    const isInFavourites = AppStore.favouriteAuctions.some((item) => item.id === auction.id)

    const [isLiked, setIsLiked] = useState(isInFavourites)

    useEffect(() => {
      if (isInFavourites !== isLiked) {
        setIsLiked(isInFavourites)
      }
    }, [isInFavourites])

    const handleLoveTap = (isLiked: boolean) => {
      const canTapLove = props.handleLoveTap(isLiked)
      if (canTapLove) {
        setIsLiked(isLiked)
      }
    }

    return (
      <div>
        <div className="d-flex align-items-center justify-content-between">
          <p className="auction-details-title">{auction.title as string}</p>
          <LoveButton liked={isLiked} onTap={handleLoveTap} transparentBackground />
        </div>
        <div className="mt-10">
          <span className="auction-details-section-title">{t('create_auction.description')}</span>
          {(auction.description as string)?.length ? (
            <span className="secondary-color auction-description-text">
              <ShowMoreText
                lines={3}
                more={t('generic.see_more')}
                less={t('generic.see_less')}
                anchorClass="blue-text"
                expanded={false}
              >
                {auction.description as string}
              </ShowMoreText>
            </span>
          ) : (
            <div>
              <span className="secondary-color">
                {t('auction_details.no_description_provided')}
              </span>
            </div>
          )}
        </div>

        <div className="top-border mt-10 ">
          <div className="d-flex align-items-center justify-content-between p-1 mt-10">
            <ShareButton url={`/auction/${auction.id}`} title={t('share.check_auction')} />
            <div>
              {auction.promotedAt && (
                <div>
                  <span className="secondary-color">{t('promote_auction.promoted_at')}: </span>
                  <span>{dayjs(auction.promotedAt).format('D MMM, H:mm')}</span>
                </div>
              )}
            </div>
            <span className="auction-details-report-text" onClick={openReport}>
              {t('auction_details.app_bar.report_auction')}
            </span>
          </div>
        </div>
      </div>
    )
  }
)
