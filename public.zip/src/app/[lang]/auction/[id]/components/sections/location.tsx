import { useTranslation } from '@/app/i18n/client'
import { Auction } from '@/core/domain/auction'
import useGlobalContext from '@/hooks/use-context'

export const AuctionDetailsLocationSection = (props: { auction: Auction }) => {
  const globalContext = useGlobalContext()
  const currentLanguage = globalContext.currentLanguage
  const { t } = useTranslation(currentLanguage)
  const { auction } = props

  return (
    <div className="w-100 d-flex flex-column">
      <div className="d-flex align-items-center justify-content-between">
        <span className="auction-details-section-title">{t('location.location')}</span>
        <span className="secondary-color">{auction.locationPretty}</span>
      </div>
      <iframe
        title="location"
        className="w-100 mt-10"
        style={{ borderRadius: 6 }}
        src={`https://www.google.com/maps?q=${auction.location.lat},${auction.location.lng}&z=15&output=embed`}
      ></iframe>
    </div>
  )
}
