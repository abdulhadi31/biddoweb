import { Auction } from '@/core/domain/auction'
import { AuctionDetailsConditionCard } from '../sections/summary/condition-card'
import { AuctionDetailsViewsCard } from '../sections/summary/views-card'

export const AuctionDetailsMobileSummary = (props: { auction: Auction }) => {
  const { auction } = props
  return (
    <div className="d-flex align-items-end justify-content-between w-100 p-16">
      <div className="auction-details-mobile-card d-block d-lg-none">
        <AuctionDetailsConditionCard simple auction={props.auction} />
      </div>
      <div className="d-none d-lg-block"></div>
      <div className="auction-details-mobile-card">
        <AuctionDetailsViewsCard auction={auction} fullWidth />
      </div>
    </div>
  )
}
