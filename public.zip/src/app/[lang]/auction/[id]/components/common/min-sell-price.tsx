import { useTranslation } from '@/app/i18n/client'
import { Icon } from '@/components/common/icon'
import { Auction } from '@/core/domain/auction'
import useGlobalContext from '@/hooks/use-context'
import { formatPrice } from '@/utils'
import { observer } from 'mobx-react-lite'

export const AuctionMinSellPrice = observer((props: { auction: Auction }) => {
  const globalContext = useGlobalContext()
  const currentLanguage = globalContext.currentLanguage
  const { t } = useTranslation(currentLanguage)

  const { auction } = props

  const computeMinPrice = () => {
    let minPrice = 1

    if (auction.bids.length) {
      const bidWithHighestPrice = auction.bids.reduce((prev, current) =>
        (prev.price ?? 0) > (current.price ?? 0) ? prev : current
      )
      minPrice = bidWithHighestPrice.price! ?? 0
    } else {
      minPrice = auction.startingPrice ?? 1
    }
    return minPrice
  }

  const minPrice = formatPrice(
    computeMinPrice(),
    currentLanguage,
    globalContext.appSettings?.defaultCurrency ?? '$'
  )

  return (
    <div className="min-sell-price-root">
      <div className="d-flex align-items-center justify-content-between w-100">
        <Icon type="generic/payment" size={48} />

        <div className="d-flex flex-column justify-content-center align-items-center price-root">
          <span className="starting-price">
            {t(
              auction.bids.length
                ? 'auction_details.create_bid.highest_bid'
                : 'auction_details.create_bid.starting_price'
            )}
          </span>
          <div className="d-flex align-items-center">
            <span className="ml-10 price">{minPrice} </span>
          </div>
        </div>
        <div></div>
      </div>

      <style jsx>{`
        .min-sell-price-root {
          display: flex;
          align-items: center;
          background: var(--clr-blue);
          border-radius: 6px;
          padding: 16px 32px;
          width: 100%;
        }
        .price-root {
          margin-right: 48px;
          color: var(--separator);
        }
        .starting-price {
          color: #fff;
        }
        .price {
          font-size: 24px;
          font-weight: 600;
          color: #fff;
        }
      `}</style>
    </div>
  )
})
