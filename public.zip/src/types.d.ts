declare module 'google-places'
