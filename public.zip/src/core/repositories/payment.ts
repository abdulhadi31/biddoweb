import { RequestMaker, RequestType } from '../services/request-maker'

class PaymentRepository {
  private basePath = '/payment'

  public async loadPaymentProducts() {
    try {
      const response = (await RequestMaker.makeRequest({
        path: `${this.basePath}/stripe-products`,
        method: RequestType.GET,
      })) as { coins: number; productId: string }[]
      return response
    } catch (error) {
      console.error('Error loading payment products:', error)
      return []
    }
  }

  public async createCheckoutSession(productId: string) {
    try {
      const response = (await RequestMaker.makeRequest({
        path: `${this.basePath}/stripe-checkout`,
        method: RequestType.POST,
        payload: JSON.stringify({ productId }),
      })) as {
        id: string
      }
      return response
    } catch (error) {
      console.error('Error creating checkout session:', error)
      return null
    }
  }
}

const paymentRepository = new PaymentRepository()
export { paymentRepository as PaymentRepository }
