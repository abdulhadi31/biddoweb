import { firebaseConfig } from '@/firebase'
import { initializeApp, getApps, FirebaseOptions } from 'firebase/app'
import {
  FacebookAuthProvider,
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  signOut,
  User,
  sendPasswordResetEmail,
} from 'firebase/auth'

class AuthService {
  private googleProvider = new GoogleAuthProvider()
  private facebookProvider = new FacebookAuthProvider()
  private firebaseUnsub!: () => void

  constructor() {
    if (!getApps().length) {
      initializeApp(firebaseConfig as FirebaseOptions)
    }
  }

  public signInWithGoogle = async () => {
    await signInWithPopup(getAuth(), this.googleProvider)
  }

  public signInWithFacebook = async () => {
    await signInWithPopup(getAuth(), this.facebookProvider)
  }

  public signInWithEmailAndPassword = (email: string, password: string) => {
    return signInWithEmailAndPassword(getAuth(), email, password)
  }

  public async logout() {
    await signOut(getAuth())
    return true
  }

  public unsubAuthUser(): void {
    if (this.firebaseUnsub) {
      this.firebaseUnsub()
    }
  }

  public getAuthUser = async (callback: (authUser: User | null) => void) => {
    this.firebaseUnsub = onAuthStateChanged(getAuth(), callback)
  }

  public getAuthUserAsync(): Promise<User | null> {
    return new Promise((resolve) => {
      this.getAuthUser(resolve)
    })
  }

  public signUp = async (email: string, password: string) => {
    try {
      const auth = getAuth()
      const result = await createUserWithEmailAndPassword(auth, email, password)

      try {
        await sendEmailVerification(result.user)
      } catch (error) {
        console.error('Error sending email verification', error)
      }

      return true
    } catch (error) {
      if ((error as Error).message.indexOf('auth/email-already-in-use') !== -1) {
        return 'auth/email-already-in-use'
      }

      return false
    }
  }

  public reloadAuthUser() {
    try {
      return getAuth().currentUser?.reload()
    } catch (error) {
      console.error('Error reloading user', error)
      return null
    }
  }

  // Not used in the app, but it might be useful for you
  public async sendPasswordResetEmail(email: string) {
    try {
      await sendPasswordResetEmail(getAuth(), email)
      return true
    } catch (error) {
      console.error('Error sending password reset email', error)
      return false
    }
  }

  // Not used in the app, but it might be useful for you
  public async resendEmailVerification() {
    try {
      const currentUser = getAuth().currentUser
      if (!currentUser) {
        return false
      }

      await sendEmailVerification(currentUser)
      return true
    } catch (error) {
      console.error('Error resending email verification', error)
      return false
    }
  }
}

const authService = new AuthService()
export { authService as AuthService }
