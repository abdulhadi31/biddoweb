import { PaymentRepository } from '../repositories/payment'

class PaymentsController {
  async loadPaymentProducts() {
    return await PaymentRepository.loadPaymentProducts()
  }

  async createCheckoutSession(productId: string) {
    return await PaymentRepository.createCheckoutSession(productId)
  }
}

const paymentsController = new PaymentsController()
export { paymentsController as PaymentsController }
