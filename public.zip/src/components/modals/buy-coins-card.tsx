import { useTranslation } from '@/app/i18n/client'
import useGlobalContext from '@/hooks/use-context'
import { useState } from 'react'
import { Icon } from '../common/icon'
import { useScreenIsBig } from '@/hooks/use-screen-is-big'

export const BuyCoinsCard = (props: {
  coins: number
  background: string
  onBuyCoins: () => Promise<void>
}) => {
  const globalContext = useGlobalContext()
  const currentLanguage = globalContext.currentLanguage
  const { t } = useTranslation(currentLanguage)

  const { coins, background, onBuyCoins } = props

  const [purchaseInProgress, setPurchaseInProgress] = useState(false)
  const screenIsBig = useScreenIsBig()

  const handleBuy = async () => {
    if (purchaseInProgress) {
      return
    }

    setPurchaseInProgress(true)
    await onBuyCoins()
    setPurchaseInProgress(false)
  }

  return (
    <div className="buy-coins-card-root p-16" style={{ ...(background ? { background } : {}) }}>
      <p className="d-flex align-items-center gap-2">
        <Icon type="generic/coin" />
        <span className="fw-bold">{t('buy_coins.coins_no', { no: coins })}</span>
      </p>
      <p className="m-0">{t('info.buy_coins_description')}</p>

      <div className="d-flex justify-content-end">
        <button
          className={`fill-btn buy-coins-btn ${screenIsBig ? '' : 'mt-2'}`}
          disabled={purchaseInProgress}
          onClick={handleBuy}
        >
          {purchaseInProgress ? (
            <div className="loader-wrapper d-flex align-items-center justify-content-center">
              <Icon type="loading" color={'#000'} size={40} />
            </div>
          ) : (
            t('buy_coins.buy_coins')
          )}
        </button>
      </div>
      <style jsx>{`
        .buy-coins-card-root {
          border-radius: 6px;
        }

        .buy-coins-card-root p {
          color: #fff;
        }

        .buy-coins-btn {
          background: #fff;
          color: #000;
        }
      `}</style>
    </div>
  )
}
