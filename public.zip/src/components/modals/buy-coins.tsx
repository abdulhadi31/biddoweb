'use client'
import { useTranslation } from '@/app/i18n/client'
import useGlobalContext from '@/hooks/use-context'
import { CustomModal } from '../common/custom-modal'
import { Icon } from '../common/icon'
import { loadStripe } from '@stripe/stripe-js'
import { AppStore } from '@/core/store'
import { NoDataCard } from '../common/no-data-card'
import { observer } from 'mobx-react-lite'
import { useState } from 'react'
import { PaymentsController } from '@/core/controllers/payment'
import { toast } from 'react-toastify'
import { BuyCoinsCard } from './buy-coins-card'

interface BuyCoinsModalProps {
  isOpened: boolean
  close: () => void
}

const CARDS_COLORS = ['#F45C43', '#DC4973', '#AB4F8F']

export const BuyCoinsModal = observer((props: BuyCoinsModalProps) => {
  const { isOpened, close } = props
  const globalContext = useGlobalContext()
  const currentLanguage = globalContext.currentLanguage
  const { t } = useTranslation(currentLanguage)

  const availableProducts = AppStore.paymentProducts
  const [paymentInProgress, setPaymentInProgress] = useState(false)

  const productsWithId = availableProducts.filter((product) => product.productId)

  const handlePurchase = async (productId: string) => {
    if (paymentInProgress) {
      return
    }

    const stripe = await loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLIC_KEY as string)
    if (!stripe) {
      return
    }

    setPaymentInProgress(true)
    const checkoutSession = await PaymentsController.createCheckoutSession(productId)
    setPaymentInProgress(false)

    if (!checkoutSession) {
      toast.error(t('generic.something_went_wrong'))
      return
    }

    try {
      await stripe.redirectToCheckout({
        sessionId: checkoutSession.id,
      })
      toast.success(t('info.payment_success'))
    } catch (error) {
      console.error(`Failed to redirect to checkout: ${error}`)
      toast.error(t('generic.something_went_wrong'))
    }
  }

  return (
    <CustomModal
      open={isOpened}
      onClose={close}
      styles={{
        modal: {
          maxWidth: '450px',
          backgroundColor: 'var(--background_2)',
        },
        overlay: {
          background: 'rgba(0, 0, 0, 0.5)',
        },
      }}
      classNames={{
        modal: 'info-modal',
      }}
      closeIcon={<Icon type="generic/close-filled" />}
      center
    >
      <h4 className="mb-10">{t('buy_coins.buy_coins')}</h4>
      {!productsWithId?.length && (
        <NoDataCard
          title="No products available inside the app."
          background="var(--background_2)"
        />
      )}

      <div className="d-flex flex-column gap-2">
        {productsWithId?.map((product, index) => {
          return (
            <BuyCoinsCard
              background={CARDS_COLORS[index]}
              key={index}
              coins={product.coins}
              onBuyCoins={() => handlePurchase(product.productId)}
            />
          )
        })}
      </div>
    </CustomModal>
  )
})
