import dayjs from 'dayjs'
import Image from 'next/image'
import Link from 'next/link'
import { EMOJI_PATTERN } from './utils'
import { generateNameForAccount } from '@/utils'
import { ChatMessage } from '@/core/domain/chat-message'
import { Account } from '@/core/domain/account'

export const ChatMessageItem = (props: {
  message: ChatMessage
  currentAccount: Account
  senderAccount: Account
}) => {
  const { message, currentAccount, senderAccount } = props

  const wrapEmojis = (text: string) => {
    return text?.replace(EMOJI_PATTERN, (match) => `<span class="emoji">${match}</span>`)
  }

  const messageContent = message.message
  const newContent = wrapEmojis(messageContent)

  const renderMessageFromCurrentAccount = () => {
    return (
      <div className="d-flex align-items-start justify-content-end" style={{ padding: 16 }}>
        <div className="mr-10 d-flex flex-column align-items-end">
          <span className="fw-light message-date-container">
            {dayjs(message.createdAt).format('D MMM, H:mm')}
          </span>
          <div className="message-container mt-0" style={{ borderRadius: '16px 0 16px 16px' }}>
            <span className="message-text" dangerouslySetInnerHTML={{ __html: newContent }}></span>
          </div>
        </div>

        <div className="message-sender-picture-container">
          <Link href={`/account/${currentAccount.id}`}>
            <Image
              src={currentAccount.picture}
              height={40}
              width={40}
              alt="account picture"
              style={{ borderRadius: '50%' }}
            />
          </Link>
        </div>
      </div>
    )
  }

  if (senderAccount?.id === currentAccount?.id) {
    return renderMessageFromCurrentAccount()
  }

  return (
    <div className="d-flex align-items-start justify-content-start" style={{ padding: 16 }}>
      <div className="message-sender-picture-container">
        <Link href={`/account/${senderAccount.id}`}>
          <Image
            src={senderAccount.picture}
            height={40}
            width={40}
            alt="account picture"
            style={{ borderRadius: '50%' }}
          />
        </Link>
      </div>

      <div className="mr-10 d-flex flex-column align-items-start ml-10">
        <div className="d-flex align-items-center">
          <Link href={`/account/${senderAccount.id}`}>
            <span className="message-sender-name">{generateNameForAccount(senderAccount)}</span>
          </Link>
          <span className="fw-light ml-20 message-date-container">
            {dayjs(message.createdAt).format('D MMM, H:mm')}
          </span>
        </div>
        <div className="message-container mt-0" style={{ borderRadius: '0 16px 16px 16px' }}>
          <span className="message-text" dangerouslySetInnerHTML={{ __html: newContent }}></span>
        </div>
      </div>
    </div>
  )
}
