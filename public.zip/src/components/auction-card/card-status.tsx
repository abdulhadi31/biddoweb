'use client'
import { useTranslation } from '@/app/i18n/client'
import { Auction } from '@/core/domain/auction'
import useGlobalContext from '@/hooks/use-context'
import { Icon } from '../common/icon'
import { Countdown } from '../common/countdown'

export const AuctionCardStatus = (props: { auction: Auction; large?: boolean }) => {
  const globalContext = useGlobalContext()
  const currentLanguage = globalContext.currentLanguage
  const { t } = useTranslation(currentLanguage)

  const { auction, large } = props

  let dateToCheck = auction.createdAt
  if (typeof dateToCheck === 'string') {
    dateToCheck = new Date(dateToCheck)
  }

  try {
    dateToCheck.getTime()
  } catch (e) {
    console.error('Invalid date format', e)
    return null
  }

  const AUCTION_ACTIVE_TIME_IN_HOURS = globalContext.appSettings?.auctionActiveTimeInHours ?? 96
  const deadline = new Date(
    (dateToCheck?.getTime() ?? -AUCTION_ACTIVE_TIME_IN_HOURS) +
      AUCTION_ACTIVE_TIME_IN_HOURS * 60 * 60 * 1000
  )
  const now = new Date()
  const durationDiff = Number(deadline) - Number(now)

  const bidAccepted = auction.acceptedBidId != null
  const isClosed = !auction.isActive || durationDiff < 0 || bidAccepted

  if (bidAccepted) {
    return (
      <p className="auction-card-status d-flex align-items-center m-0">
        {t('auction_details.accepted_bid')}
        <style jsx>{`
          .auction-card-status {
            color: var(--success);
            white-space: nowrap;
            font-size: 18px;
          }
        `}</style>
      </p>
    )
  }

  if (isClosed) {
    return (
      <p className="auction-card-status m-0">
        {t('auction_details.closed')}
        <style jsx>{`
          .auction-card-status {
            color: var(--call_to_action);
            white-space: nowrap;
            font-size: 18px;
          }
        `}</style>
      </p>
    )
  }

  return (
    <div className="countdown-wrapper">
      <div className="hourglass-wrapper">
        <Icon type="generic/hourglass" size={large ? 24 : 18} />
      </div>
      <Countdown deadlineDate={deadline} large={large} />
    </div>
  )
}
