import { useTranslation } from '@/app/i18n/client'
import { AppStore } from '@/core/store'
import useGlobalContext from '@/hooks/use-context'
import { observer } from 'mobx-react-lite'
import Link from 'next/link'

export const CreateAuctionButton = observer(
  (props: { height?: number; handleClick?: () => void }) => {
    const { height, handleClick } = props
    const globalContext = useGlobalContext()
    const currentLanguage = globalContext.currentLanguage
    const { t } = useTranslation(currentLanguage)

    return (
      <>
        <Link
          onClick={() => {
            handleClick?.()
          }}
          href={AppStore.accountData?.id ? '/auction-create' : '/auth/login'}
          className="fill-btn create-auction-btn"
          style={{ ...(height ? { height } : {}) }}
        >
          <span> {t('create_auction.create_auction')}</span>
        </Link>
      </>
    )
  }
)
