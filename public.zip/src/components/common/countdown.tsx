'use client'
import { useTranslation } from '@/app/i18n/client'
import useGlobalContext from '@/hooks/use-context'
import React from 'react'
import { default as ReactCountdown } from 'react-countdown'

export const Countdown = ({
  deadlineDate = new Date(),
  large = false,
  small = false,
  withDays = false,
}) => {
  const globalContext = useGlobalContext()
  const currentLanguage = globalContext.currentLanguage
  const { t } = useTranslation(currentLanguage)

  const renderer = (params: {
    days: number
    hours: number
    minutes: number
    seconds: number
    completed: boolean
  }) => {
    const { days, minutes, seconds, completed } = params
    let { hours } = params

    if (!withDays) {
      hours += days * 24
    }

    if (completed) {
      return (
        <p className="auction-card-status">
          {t('auction_details.closed')}{' '}
          <style jsx>{`
            .auction-card-status {
              color: var(--clr-theme-1);
              white-space: nowrap;
              font-size: ${large ? 36 : small ? 16 : 24}px;
            }
          `}</style>
        </p>
      )
    }

    return (
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-evenly',
          alignItems: 'center',
          fontSize: small ? 14 : large ? 24 : 16,
          color: 'var(--font_1)',
        }}
      >
        {withDays && (
          <>
            <div style={{ textAlign: 'start', width: small ? 24 : 35 }}>
              <span>{days.toString().padStart(2, '0')}</span>
            </div>
            <div style={{ paddingRight: 6 }}>:</div>
          </>
        )}
        <div style={{ textAlign: 'start', width: small ? 24 : 30 }}>
          <span>{hours.toString().padStart(2, '0')}</span>
        </div>
        <div style={{ paddingRight: 6 }}>:</div>
        <div style={{ textAlign: 'start', width: small ? 24 : 30 }}>
          {minutes.toString().padStart(2, '0')}
        </div>
        <div style={{ paddingRight: 6 }}>:</div>
        <div style={{ textAlign: 'start', width: small ? 24 : 30 }}>
          {seconds.toString().padStart(2, '0')}
        </div>
      </div>
    )
  }

  return <ReactCountdown date={deadlineDate} renderer={renderer} />
}
