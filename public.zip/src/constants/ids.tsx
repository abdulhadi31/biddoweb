export const ELEMENT_IDS = {
  GLOBAL_SEARCH_INPUT: 'global-search-input',
  FAVOURITES_HEADER_BTN: 'favourites-header-btn',
  NOTIFICATIONS_HEADER_BTN: 'notifications-header-btn',
  CHAT_HEADER_BTN: 'chat-header-btn',
  ACCOUNT_HEADER_BTN: 'account-header-btn',
}
