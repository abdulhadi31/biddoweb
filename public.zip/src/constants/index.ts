export const TUTORIAL_LINKS = {
  CREATE_AUCTION: 'https://www.google.com',
  CREATE_BID: 'https://www.google.com',
}

export const MOBILE_APP_LINKS = {
  GOOGLE_PLAY_LINK: 'https://play.google.com/store/apps/details?id=com.google.android.apps.maps',
  APP_STORE_LINK: 'https://www.apple.com/ios/app-store/',
}

export const APP_NAME = 'Biddo'

export const SESSION_COOKIE_NAME = 'session_cookie'

export const SEO = {
  IMAGE_URL: 'https://www.google.com',
  TWITTER_IMAGE_URL: 'https://www.google.com',
}
