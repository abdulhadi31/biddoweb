export const GENERAL_ERRORS = {
  TOO_MANY_ASSETS: 'Too many assets',
  ASSET_TOO_BIG: 'Asset too big',
  ASSET_NOT_SUPPORTED: 'Asset not supported',
}
